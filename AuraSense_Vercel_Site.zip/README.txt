AuraSense Technologies - Vercel deployment
==========================================

Files
  index.html   The complete website (all code, styles and images inside)
  vercel.json  Vercel settings (clean URLs, basic security headers)

Deploy (drag and drop)
  1. Go to vercel.com and log in.
  2. Click "Add New" > "Project", then drag this unzipped folder in
     (or use "vercel" from the command line inside this folder).
  3. Framework Preset: "Other". Leave build settings empty. Click Deploy.

Activate the contact form (one time only)
  1. Open your live Vercel link and submit the contact form once.
  2. FormSubmit emails hello.aurasense@gmail.com an activation link.
     Click it (check spam if you don't see it).
  3. From then on, every enquiry arrives in that inbox.
  If you add a custom domain later, submit the form once from it and
  confirm again if asked.
